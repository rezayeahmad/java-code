public class PolymorphismDemo {
    public static void main(String[] args) {
        // Polymorphism: Supertype variables referring to subtype objects
        GeometricObject object1 = new Circle(5.0, "red", true);
        GeometricObject object2 = new Rectangle(2.0, 3.0, "blue", false);

        // Display properties using dynamic binding
        System.out.println("Displaying Object 1 details:");
        displayObject(object1);

        System.out.println("\nDisplaying Object 2 details:");
        displayObject(object2);
    }

    /** A method that takes any GeometricObject (Supertype) */
    public static void displayObject(GeometricObject object) {
        // Automatically calls the correct toString() based on actual object type
        System.out.println(object.toString());
        System.out.println("Color: " + object.getColor());
        System.out.println("Filled: " + object.isFilled());
    }
}

// Superclass (Supertype)
class GeometricObject {
    private String color = "white";
    private boolean filled;

    public GeometricObject() {}

    public GeometricObject(String color, boolean filled) {
        this.color = color;
        this.filled = filled;
    }

    public String getColor() { return color; }
    public boolean isFilled() { return filled; }

    @Override
    public String toString() {
        return "Generic Geometric Object";
    }
}

// Subclass (Subtype)
class Circle extends GeometricObject {
    private double radius;

    public Circle(double radius, String color, boolean filled) {
        super(color, filled); // Call superclass constructor
        this.radius = radius;
    }

    public double getRadius() { return radius; }
    public double getArea() { return Math.PI * radius * radius; }

    @Override
    public String toString() {
        return "Circle with radius = " + radius + " and area = " + Math.round(getArea() * 100.0) / 100.0;
    }
}

// Additional Subclass to emphasize polymorphism flexibility
class Rectangle extends GeometricObject {
    private double width;
    private double height;

    public Rectangle(double width, double height, String color, boolean filled) {
        super(color, filled);
        this.width = width;
        this.height = height;
    }

    @Override
    public String toString() {
        return "Rectangle with width = " + width + " and height = " + height;
    }
}
