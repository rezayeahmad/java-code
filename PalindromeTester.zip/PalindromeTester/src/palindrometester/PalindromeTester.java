import java.util.Scanner;

public class PalindromeTester {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String text = input.nextLine();

        // Create an instance of our object-oriented checker
        PalindromeChecker checker = new PalindromeChecker(text);

        // Display results
        System.out.println("Filtered string: " + checker.getFilteredText());
        if (checker.isPalindrome()) {
            System.out.println("The string is a palindrome.");
        } else {
            System.out.println("The string is NOT a palindrome.");
        }
    }
}

class PalindromeChecker {
    private String originalText;
    private String filteredText;

    /** Constructor initializing the checker with the user input */
    public PalindromeChecker(String text) {
        this.originalText = text;
        this.filteredText = filterNonAlphanumeric(text);
    }

    /** Helper method to filter out non-alphanumeric characters and unify case */
    private String filterNonAlphanumeric(String text) {
        StringBuilder sb = new StringBuilder();
        
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            // Keep only letters and digits, converted to lowercase for case-insensitivity
            if (Character.isLetterOrDigit(ch)) {
                sb.append(Character.toLowerCase(ch));
            }
        }
        return sb.toString();
    }

    /** Core business logic to verify if the filtered text is a palindrome */
    public boolean isPalindrome() {
        int low = 0;
        int high = filteredText.length() - 1;

        while (low < high) {
            if (filteredText.charAt(low) != filteredText.charAt(high)) {
                return false; // Character mismatch found
            }
            low++;
            high--;
        }
        return true;
    }

    // Getter methods
    public String getOriginalText() {
        return originalText;
    }

    public String getFilteredText() {
        return filteredText;
    }
}
